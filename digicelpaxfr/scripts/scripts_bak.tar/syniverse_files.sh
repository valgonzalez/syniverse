#!/bin/bash
#
#
#Script para buscar archivos a equipo windows y enviar a syniverse
#

destmail="edey.williams@digicelgroup.com,juan.berrio@digicelgroup.com,Pan_Application_Team@digicelgroup.com"

cat /dev/null > /home/digicelpaxfr/scripts/scp.log

(echo ;date;echo ) >> /home/digicelpaxfr/scripts/scp.log

/home/digicelpaxfr/scripts/ftp_script.sh >> /home/digicelpaxfr/scripts/scp.log

/home/digicelpaxfr/scripts/scp_script.sh >> /home/digicelpaxfr/scripts/scp.log

# Optional line
# [ $? -ne 0 ] && ( echo Not files found | mailx -s "Syniverse send file failed" $destmail ) ||  ( echo files sent ok. | mailx -s "Syniverse send file OK" $destmail )

cat /home/digicelpaxfr/scripts/scp.log |  mailx -s "Syniverse send file process complete"  $destmail
